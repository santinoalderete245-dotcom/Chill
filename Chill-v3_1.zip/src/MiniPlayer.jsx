import { useState, useEffect, useRef, useCallback, memo } from "react";
import "./MiniPlayer.css";

/* ─── helpers ─────────────────────────────────────────────── */
function fmt(s) {
  if (!s || isNaN(s)) return "0:00";
  return `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;
}

/* ─── Visualizer canvas (16 barras, 30 fps, liviano) ──────── */
const MiniVisualizer = memo(function MiniVisualizer({ bars }) {
  // bars es el array de 64 valores que ya calcula App.jsx
  // tomamos 16 barras distribuidas uniformemente
  const sample = Array.from({ length: 16 }, (_, i) => {
    const idx = Math.floor((i / 16) * bars.length);
    return bars[idx] ?? 2;
  });

  return (
    <div className="mp-viz" aria-hidden="true">
      {sample.map((h, i) => (
        <div
          key={i}
          className="mp-viz-bar"
          style={{ height: `${Math.max(2, Math.min(18, (h / 100) * 18))}px` }}
        />
      ))}
    </div>
  );
});

/* ─── Barra de progreso clickeable ───────────────────────────*/
function SeekBar({ progress, duration, onSeek }) {
  const pct = duration > 0 ? (progress / duration) * 100 : 0;

  function handleClick(e) {
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = (e.clientX - rect.left) / rect.width;
    onSeek(ratio * duration);
  }

  return (
    <div className="mp-seek" onClick={handleClick} role="slider"
      aria-label="Progreso" aria-valuenow={Math.round(progress)} aria-valuemin={0} aria-valuemax={Math.round(duration)}>
      <div className="mp-seek-fill" style={{ width: `${pct}%` }} />
    </div>
  );
}

/* ─── Barra de volumen clickeable ────────────────────────────*/
function VolBar({ volume, onVolume }) {
  function handleClick(e) {
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    onVolume(ratio);
  }

  const icon = volume === 0 ? "🔇" : volume < 0.4 ? "🔈" : "🔊";

  return (
    <div className="mp-vol-row">
      <span className="mp-vol-icon">{icon}</span>
      <div className="mp-vol-track" onClick={handleClick}
        role="slider" aria-label="Volumen" aria-valuenow={Math.round(volume * 100)}
        aria-valuemin={0} aria-valuemax={100}>
        <div className="mp-vol-fill" style={{ width: `${volume * 100}%` }} />
      </div>
    </div>
  );
}

/* ─── Componente principal ───────────────────────────────────*/
export default memo(function MiniPlayer({
  currentSong,
  playing,
  progress,
  duration,
  volume,
  bars,
  onPlay,
  onPrev,
  onNext,
  onSeek,
  onVolume,
  onAISuggest,   // (currentSong, recentTitles) => void — IA elige próxima canción
  recentSongs,   // array de strings con títulos recientes (para contexto IA)
}) {
  const [visible, setVisible] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [pinned, setPinned] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiHint, setAiHint] = useState("");      // mensaje corto de lo que eligió la IA

  // Refs para evitar stale closures en callbacks de timer
  const hideTimerRef = useRef(null);
  const playerRef = useRef(null);
  const pinnedRef = useRef(false);
  const expandedRef = useRef(false);

  // Mantener refs sincronizados
  useEffect(() => { pinnedRef.current = pinned; }, [pinned]);
  useEffect(() => { expandedRef.current = expanded; }, [expanded]);

  /* ── Lógica de visibilidad ─────────────────────────────── */
  const showPlayer = useCallback(() => {
    clearTimeout(hideTimerRef.current);
    setVisible(true);
  }, []);

  // scheduleHide lee pinnedRef (siempre fresco, sin stale closure)
  const scheduleHide = useCallback(() => {
    if (pinnedRef.current) return;
    clearTimeout(hideTimerRef.current);
    hideTimerRef.current = setTimeout(() => {
      setVisible(false);
      setExpanded(false);
    }, 600);
  }, []);

  /* ── Hover zone: detectar proximidad a la esquina ──────── */
  useEffect(() => {
    let throttleTimer = null;

    function onMouseMove(e) {
      if (throttleTimer) return;
      throttleTimer = setTimeout(() => {
        throttleTimer = null;
        // FIX Bug 3: chequear esquina bottom-RIGHT
        const nearCorner =
          e.clientX > window.innerWidth - 160 &&
          e.clientY > window.innerHeight - 160;
        if (nearCorner) {
          showPlayer();
        }
      }, 80);
    }

    window.addEventListener("mousemove", onMouseMove, { passive: true });
    return () => {
      window.removeEventListener("mousemove", onMouseMove);
      clearTimeout(throttleTimer);
      clearTimeout(hideTimerRef.current);
    };
  }, [showPlayer]);

  /* ── Cleanup al desmontar ──────────────────────────────── */
  useEffect(() => {
    return () => clearTimeout(hideTimerRef.current);
  }, []);

  /* ── Clases dinámicas del root ─────────────────────────── */
  const rootClasses = [
    "mp-root",
    visible ? "mp-visible" : "",
    expanded ? "mp-expanded" : "",
    pinned ? "mp-pinned" : "",
    !currentSong ? "mp-no-song" : "",
  ].filter(Boolean).join(" ");

  const discClasses = [
    "mp-disc",
    playing ? "mp-spinning" : "mp-paused",
  ].join(" ");

  /* ── Render ────────────────────────────────────────────── */
  return (
    <>
      {/* Zona de detección invisible — amplía el área de hover cerca del corner */}
      {!visible && (
        <div
          className="mp-hover-zone"
          onMouseEnter={showPlayer}
          aria-hidden="true"
        />
      )}

      <div className={rootClasses}>
        {/* Orbe discreto (estado oculto) */}
        <div
          className="mp-orb"
          onClick={showPlayer}
          title="Abrir reproductor"
          aria-label="Abrir mini reproductor"
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === "Enter" && showPlayer()}
        />

        {/* Player */}
        <div
          ref={playerRef}
          className="mp-player"
          onMouseEnter={() => {
            clearTimeout(hideTimerRef.current);
            setExpanded(true);
            setVisible(true);
          }}
          onMouseLeave={() => {
            if (pinnedRef.current) {
              // Si está fijado: restaurar al estado que tenía cuando se fijó
              setExpanded(expandedRef.current);
            } else {
              setExpanded(false);
              scheduleHide();
            }
          }}
        >
          {/* Botón PIN */}
          <button
            className="mp-pin-btn"
            onClick={() => {
              setPinned((p) => {
                const next = !p;
                if (next) {
                  // Al fijar: recordar si estaba expandido ahora
                  expandedRef.current = expanded;
                } else {
                  // Al desfijar: restaurar expanded al estado guardado
                  setExpanded(expandedRef.current);
                }
                return next;
              });
            }}
            title={pinned ? "Desfijar reproductor" : "Fijar reproductor"}
            aria-label={pinned ? "Desfijar reproductor" : "Fijar reproductor"}
            aria-pressed={pinned}
          />

          {/* ── SECCIÓN MINI ─────────────────────────────── */}
          <div className="mp-mini">
            {/* Disco */}
            <div className="mp-disc-wrap" aria-hidden="true">
              <div className={discClasses}>
                <div className="mp-disc-hole" />
              </div>
            </div>

            {/* Info */}
            <div className="mp-info">
              {currentSong ? (
                <>
                  <div className="mp-song-title" title={currentSong.title}>
                    {currentSong.title}
                  </div>
                  {currentSong.artist && (
                    <div className="mp-song-artist" title={currentSong.artist}>
                      {currentSong.artist}
                    </div>
                  )}
                </>
              ) : (
                <div className="mp-song-idle">Sin reproducción</div>
              )}
            </div>

            {/* Controles */}
            <div className="mp-controls" role="group" aria-label="Controles">
              <button
                className="mp-btn"
                onClick={onPrev}
                title="Anterior"
                aria-label="Canción anterior"
                disabled={!currentSong}
              >
                ⏮
              </button>
              <button
                className="mp-btn mp-btn-play"
                onClick={onPlay}
                title={playing ? "Pausar" : "Reproducir"}
                aria-label={playing ? "Pausar" : "Reproducir"}
                disabled={!currentSong}
              >
                {playing ? "⏸" : "▶"}
              </button>
              <button
                className="mp-btn"
                onClick={onNext}
                title="Siguiente"
                aria-label="Siguiente canción"
                disabled={!currentSong}
              >
                ⏭
              </button>
            </div>
          </div>

          {/* ── SECCIÓN EXPANDIDA ─────────────────────────── */}
          <div className="mp-ext" aria-hidden={!expanded}>
            <div className="mp-expanded-inner">
              <div className="mp-divider" />

              {/* Visualizador */}
              <MiniVisualizer bars={bars} />

              {/* Progreso */}
              <div className="mp-progress-row">
                <span className="mp-time">{fmt(progress)}</span>
                <SeekBar progress={progress} duration={duration} onSeek={onSeek} />
                <span className="mp-time">{fmt(duration)}</span>
              </div>

              {/* Volumen */}
              <VolBar volume={volume} onVolume={onVolume} />

              {/* Botón IA */}
              {onAISuggest && (
                <button
                  className={`mp-ai-btn${aiLoading ? " mp-ai-loading" : ""}`}
                  disabled={aiLoading || !currentSong}
                  onClick={async () => {
                    if (!onAISuggest || aiLoading) return;
                    setAiLoading(true);
                    setAiHint("");
                    try {
                      const hint = await onAISuggest(currentSong, recentSongs || []);
                      if (hint) setAiHint(hint);
                    } finally {
                      setAiLoading(false);
                    }
                  }}
                  title="La IA elige la próxima canción"
                >
                  <span className="mp-ai-icon">{aiLoading ? "⟳" : "✦"}</span>
                  <span className="mp-ai-label">
                    {aiLoading ? "Eligiendo..." : "Sorpréndeme"}
                  </span>
                </button>
              )}

              {/* Hint de IA */}
              {aiHint && (
                <div className="mp-ai-hint">{aiHint}</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
});
